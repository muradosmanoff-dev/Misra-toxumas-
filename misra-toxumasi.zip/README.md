# Misra Toxuması

Sözlərdən Azərbaycan dilində şeir toxuyan, telefon ekranına tətbiq kimi əlavə oluna bilən kiçik veb tətbiq.

## GitHub Pages-ə necə qoymalı?

1. **GitHub hesabı aç** (əgər yoxdursa): https://github.com/signup

2. **Yeni repo yarat**:
   - github.com-da sağ yuxarı küncdə "+" işarəsinə bas → "New repository"
   - Ad ver, məsələn: `misra-toxumasi`
   - "Public" seç
   - "Create repository" düyməsinə bas

3. **Faylları yüklə**:
   - Yeni açılan repo səhifəsində "uploading an existing file" linkinə bas
   - Bu qovluqdaki 3 faylı (`index.html`, `manifest.json`, `icon.png`) sürüşdürüb burax
   - Aşağıda "Commit changes" düyməsinə bas

4. **GitHub Pages-i aktiv et**:
   - Repo səhifəsində "Settings" sekməsinə keç
   - Sol menyudan "Pages"i tap
   - "Branch" hissəsində `main` seç, qarşısındaki qovluğu `/ (root)` saxla, "Save" bas
   - Bir-iki dəqiqə gözlə, səhifəni yenilə — yuxarıda yaşıl bir qutu içində linkin görünəcək:
     `https://SƏNIN-ADIN.github.io/misra-toxumasi/`

5. **Telefonda aç və ekrana əlavə et**:
   - Bu linki telefonunda Safari (iPhone) və ya Chrome (Android) ilə aç
   - **iPhone**: Paylaş düyməsi → "Ana ekrana əlavə et"
   - **Android**: Üç nöqtəli menyu → "Ana ekrana əlavə et" / "Tətbiq quraşdır"

6. **API açarını əlavə et**:
   - Tətbiqi ilk açışda "Bir dəfəlik qurğu" qutusu çıxacaq
   - https://console.anthropic.com/settings/keys ünvanından özünə bir API açarı yarat
   - Açarı yapışdır, "Saxla" bas — bundan sonra yalnız bu telefonda yadda saxlanılır

## Qeyd

API açarın brauzerin öz yaddaşında (localStorage) saxlanılır, heç bir serverə göndərilmir. Açarını başqası ilə paylaşma.
